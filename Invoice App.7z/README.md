# DESCRIPTION
This app I made I used Sveltejs, and SCSS. I wanted to prove to myself I can be a good problem solver by making a invoice app. The Idea I got was from FrontEndMentor.io, they gave me the design system a few screenshots and I went to town with it. I did take a few liberties with the design and my own take on it. To make it better.

# DIFFICULTIES
One of the biggest challenge i had in this wasn't nessassarily the code it self, but to be more effectient, there are alot of a moving parts - for example, depending on the theme (light or dark) text and background color changes on certain components, to get this done quickly and easily as possibile I had to make a components within components within more components, that added some complexitiy to the app, I think I named them appropriotely to understand what did what, so if in the event I come back to this, will get the maintainer some idea of what these things do. That is also another thing, I wanted this to be easily maintainable with little trouble involved. which is a challenge, but in my opinion I made it someone meaningful.


# IMPROVEMENTS
One idea I think might need to invest time into to do well going forward maybe in the future is perhaps implement some graphs to showcase the percentage of that isn't completed, that are and what are in draft.